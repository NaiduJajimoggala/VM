//
//  PeopleTableViewCell.swift
//  VM
//
//  Created by Swami Naidu on 22/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import UIKit

class PeopleTableViewCell: UITableViewCell {
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var pImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var jobTitle: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    
    var person: Person? {
        didSet {
            guard let person = person else { return }
            
            nameLabel.text = person.firstName
            nameLabel.textColor = Utility.hexStringToUIColor(hex: "#C40202")
            phoneNumberLabel.text = person.phone
            jobTitle.text = person.jobTitle
            emailLabel.text = person.email
            pImage.image = UIImage(named: "ImageMissing")
            
            if let url = URL(string: person.avatar ?? "") {
                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    guard let data = data, error == nil else { return }
                    
                    DispatchQueue.main.async { /// execute on main thread
                        self.pImage.image = UIImage(data: data)
                    }
                }
                
                task.resume()
            }
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
