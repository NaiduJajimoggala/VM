//
//  Rooms.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation

// MARK: - Room
struct Room: Codable {
    let id, createdAt, name: String?
    let maxOccupancy: Int?
    let isOccupied: Bool?

    enum CodingKeys: String, CodingKey {
        case id
        case createdAt = "created_at"
        case name
        case maxOccupancy = "max_occupancy"
        case isOccupied = "is_occupied"
    }
}

typealias Rooms = [Room]
