//
//  People.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation

// MARK: - Person
struct Person: Codable {
    let avatar: String?
    let phone, firstName, id: String?
    let longitude: Double?
    let favouriteColor, email, jobTitle, createdAt: String?
    let latitude: Double?
    let lastName: String?
}

typealias People = [Person]
