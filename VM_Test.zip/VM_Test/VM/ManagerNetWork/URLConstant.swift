//
//  URLConstant.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation

struct APIList {
    
    private struct Domain{
        static let Dev = "https://5f7c2c8400bd74001690a583.mockapi.io/api/v1/"
    }
    
    static let roomsApi = Domain.Dev + "rooms"
    static let peopleApi = Domain.Dev +  "people"
}
