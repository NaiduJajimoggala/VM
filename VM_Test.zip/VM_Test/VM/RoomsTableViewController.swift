//
//  RoomsTableViewController.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import UIKit

class RoomsTableViewController: UITableViewController {
    
    var roomsList: Rooms = []
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
        // Do any additional setup after loading the view.
        let URLStr =  APIList.roomsApi
        
        if NetworkCheck.isConnectedToNetwork(){
            
            let activityIndicator:UIActivityIndicatorView = UIActivityIndicatorView()
            activityIndicator.center = self.view.center
            activityIndicator.hidesWhenStopped = true
            activityIndicator.color = Utility.hexStringToUIColor(hex: "#C40202")
            view.addSubview(activityIndicator)
            activityIndicator.startAnimating()
            
            ApiManager().RequestGetServiceWithDecodeClass(apiName: URLStr) { (objRooms:Rooms) in
                if objRooms.count > 0{
                    self.roomsList = objRooms
                }
                self.tableView?.reloadData()
                activityIndicator.stopAnimating()
                
            }
            
        }else{
            showInternetAlert()
        }
        
    }
    func showInternetAlert(){
        let alert = UIAlertController(title: "No Internet Detected", message: "This app requires an Internet connection", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return roomsList.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RoomCell", for: indexPath) as! RoomCell
        cell.room = self.roomsList[indexPath.row]
        return cell
    }
    
    
    //    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
    //        return 200.0;//Choose your custom row height
    //    }
}
